# Главная точка запуска бота

if __name__ == '__main__':
    print('Wax Sniper Bot запускается...')